//
//  Library.swift
//  CULibraries
//
//  Created by 过仲懿 on 4/27/22.
//

import Foundation

struct Library: Codable {
    var name: String?
    var time: String?
    var location: String?
    var foodAllowed: Bool?
    var status: Bool?
    var address: String?
    
    init(name: String, status: Bool, address: String) {
        self.address = address
        self.name = name
        self.status = status
    }
    
}
