//
//  ViewController.swift
//  CULibraries
//
//  Created by 过仲懿 on 4/27/22.
//

import UIKit

class MainController: UIViewController, UISearchResultsUpdating {
    
    let searchController = UISearchController()
    let from = UILabel()
    let libraryTable = UITableView()

    var library: [Library] = []
    var reuseIdentifier = "reuseIdentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        view.backgroundColor = .systemBackground
        // navigation bar setup
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationItem.title = "Libraries"
        self.navigationController?.navigationBar.backgroundColor = .systemGreen
        self.navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        searchController.searchResultsUpdater = self
        navigationItem.searchController = searchController
        searchController.obscuresBackgroundDuringPresentation = true
        searchController.searchBar.placeholder = "Current Location"
        searchController.searchBar.isTranslucent = false
        searchController.searchBar.translatesAutoresizingMaskIntoConstraints = false


        let eng = Library(name: "Engineering Library", status: false, address: "160 Ho Plaza")
        library = [eng]

        from.text = "From:"
        from.font = UIFont(name: "Times New Roman", size: 20)
        from.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(from)
        
        
//        // collection view
//        let layout = UICollectionViewFlowLayout()
//        layout.scrollDirection = .horizontal
//        layout.minimumLineSpacing = 10
//        layout.minimumInteritemSpacing = 1
//        layout.itemSize = CGSize(width: view.frame.width, height: 30)
//        let locationFilter = UICollectionView(frame: .zero, collectionViewLayout: layout)
//        locationFilter.dataSource = self
//        locationFilter.delegate = self
//        locationFilter.register(LocationFilterController.self, forCellWithReuseIdentifier: "collectionViewCell")
        
//        locationFilter.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(locationFilter)
        
        // table view
        libraryTable.dataSource = self
        libraryTable.delegate = self
        libraryTable.translatesAutoresizingMaskIntoConstraints = false
        libraryTable.register(LibraryCellController.self, forCellReuseIdentifier: reuseIdentifier)
        view.addSubview(libraryTable)
        
        
        
        setUpContraints()
    }

    func updateSearchResults(for searchController: UISearchController) {
        // TODO: filter out matching libraries
        guard let text = searchController.searchBar.text else {
            return
        }
        print(text)
    }
    
    func setUpContraints() {

//        NSLayoutConstraint.activate([
//            locationFilter.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
//            locationFilter.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
//            locationFilter.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
//            locationFilter.heightAnchor.constraint(equalToConstant: 30)
//        ])
        
        NSLayoutConstraint.activate([
            libraryTable.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            libraryTable.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            libraryTable.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            libraryTable.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        

    }

}

extension MainController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }

}

extension MainController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = libraryTable.dequeueReusableCell(withIdentifier: reuseIdentifier) as? LibraryCellController {
            let selected_library = library[indexPath.row]
            cell.configure(library: selected_library)
            return cell
            } else {
                return UITableViewCell()
            }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        library.count
    }

}

//extension MainController: UICollectionViewDataSource {
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return 5
//    }
//
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionViewCell", for: indexPath)
//        collectionCell.backgroundColor = [UIColor.green, .red, .black, .brown, .yellow].randomElement()
//        return collectionCell
//    }
//
//
//}
//
//extension MainController: UICollectionViewDelegate {
//
//}
