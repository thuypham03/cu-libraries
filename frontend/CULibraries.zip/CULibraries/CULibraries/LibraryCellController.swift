//
//  LibraryController.swift
//  CULibraries
//
//  Created by 过仲懿 on 4/27/22.
//

import Foundation
import UIKit

class LibraryCellController: UITableViewCell {
    var name = UILabel()
    var photo = UIImageView()
    var address = UILabel()
    var city = UILabel()
    var numRoomAvail = UILabel()
    var status = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .systemBackground
        selectionStyle = .default
        
        


        photo.image = UIImage(named: "ENG")
        photo.contentMode = .scaleToFill
        photo.clipsToBounds = true
        photo.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(photo)
        
        name.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        name.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(name)
        
        status.translatesAutoresizingMaskIntoConstraints = false
        status.font = UIFont(name: "HelveticaNeue-Bold", size: 15)
        contentView.addSubview(status)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            photo.topAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.topAnchor, constant: 20),
            photo.leadingAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            photo.trailingAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            photo.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        NSLayoutConstraint.activate([
            name.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 10),
            name.leadingAnchor.constraint(equalTo: photo.leadingAnchor)
        ])
        
        NSLayoutConstraint.activate([
            status.topAnchor.constraint(equalTo: name.bottomAnchor),
            status.leadingAnchor.constraint(equalTo: name.leadingAnchor)
        ])
    }
    
    
    
    func configure(library: Library) {
        name.text = library.name
        address.text = library.address
        city.text = "Ithaca, NY, 14853"
        
        if library.status == true {
            status.text = "Open"
            status.textColor = .green
        } else {
            status.text = "Closed"
            status.textColor = .red
        }
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
